#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/features2d/features2d.hpp"
#include "opencv2/flann/flann.hpp"
#include "opencv2/nonfree/nonfree.hpp"

#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <vector>
#include <string>
#include <iostream>
#include <math.h>

using namespace cv;
using namespace std;

/* get a list of filenames from directory */
int getFilenamesFromDir(string dir, vector<string> &files);
int getSubDirsFromDir(string dir, vector<string> &files);
double myDistanceSqr(Mat v1, Mat v2);

int main(int argc, char *argv[]) {
  string dir="data/";

  vector<vector<string> > filesInSubdir;
  vector<string> labelSubdirs;

  if (getSubDirsFromDir(dir, labelSubdirs) == -1) {
    cout << "Cannot get subdirs from directory : " << dir << endl;
    exit(-1);
  }

  for(unsigned int i=0;i<labelSubdirs.size();i++){
    string subdir=dir+labelSubdirs[i]+"/";

    vector<string> files;
    if (getFilenamesFromDir(subdir, files) == -1) {
      cout << "Cannot get subdirs from directory : " << subdir << endl;
      exit(-1);
    }

    filesInSubdir.push_back(files);
  }
  // === Start working from here ===




  return 0;
}

int getFilenamesFromDir(string dir, vector<string> &files) {
  DIR *dp;
  struct dirent *dirp;
  if ((dp = opendir(dir.c_str())) == NULL) {
    cout << "Error : cannot open directory : " << dir << endl;
    return -1;
  }

  while ((dirp = readdir(dp)) != NULL) {
    if (dirp->d_type == DT_REG)
      files.push_back(dir+string(dirp->d_name));
  }
  closedir(dp);
  return 0;
}

int getSubDirsFromDir(string dir, vector<string> &files) {
  DIR *dp;
  struct dirent *dirp;
  if ((dp = opendir(dir.c_str())) == NULL) {
    cout << "Error : cannot open directory : " << dir << endl;
    return -1;
  }

  while ((dirp = readdir(dp)) != NULL) {
    if (dirp->d_type == DT_DIR){
      if( strcmp(dirp->d_name,".") && strcmp(dirp->d_name,"..") )
	files.push_back(string(dirp->d_name));
    }
  }
  closedir(dp);
  return 0;
}

double myDistanceSqr(Mat v1, Mat v2) {
  if (v1.rows != v2.rows || v1.cols != v2.cols) {
    //cout << "Dimension is mismatch!!" << endl;
    return -1;
  }

  int i;
  double sum = 0.0;
  for (i = 0; i < v1.cols; i++) {
    double tmp = v1.at<float>(i) - v2.at<float>(i);
    sum += tmp * tmp;
  }
  return sum;
}

